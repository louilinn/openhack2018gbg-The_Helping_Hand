export declare function int2char(n: number): string;
export declare function op_and(x: number, y: number): number;
export declare function op_or(x: number, y: number): number;
export declare function op_xor(x: number, y: number): number;
export declare function op_andnot(x: number, y: number): number;
export declare function lbit(x: number): number;
export declare function cbit(x: number): number;
